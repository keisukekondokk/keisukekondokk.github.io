/**********************************************************
** (C) Keisuke Kondo
** Upload Date: March 31, 2018
** Update Date: April 01, 2018
** 
** [Description]
** Replication Codes and Data for Kondo (2015, JWE)
** 
** [Required Software]
** Stata 15.1 or higher version
** 
** [Required Stata Modules]
** - getisord
** - moransi
** - spgen
** NOTE: Install moransi and spgen from SSC Archive
** 
** [Reference]
** Kondo, K (2015) "Spatial persistence of Japanese unemployment rates,"
** Japan and the World Economy, 36, pp. 113-122, 2015.
** http://www.sciencedirect.com/science/article/pii/S0922142515000377
** 
**********************************************************/

#CONTENTS
1. Directories and Files
2. Replication Guide
3. Notes


#1. Directories and Files
This package includes the following two directories:
 |-FIG // Directory to store Moran scatter plots
 |-LOG // Directory to store LOG files
 |-DO_Estimation_moransi.do // DO-file for Moran's I analysis
 |-DO_Estimation_getisord.do // DO-file for Getis-Ord G*i(d) analysis
 |-DTA_ur_1980_2005_all.dta // Data file for municipal unemployment rates (all workers)
 |-DTA_ur_1980_2005_male.dta // Data file for municipal unemployment rates (male workers aged 15-29, 30-49, and 50-64)
 |-DTA_ur_1980_2005_female.dta // Data file for municipal unemployment rates (male workers aged 15-29, 30-49, and 50-64)
 |-XLSX_ur_1980_2005_all.xlsx // Data file for municipal unemployment rates (all workers)
 |-XLSX_ur_1980_2005_male.xlsx // Data file for municipal unemployment rates (male workers aged 15-29, 30-49, and 50-64)
 |-XLSX_ur_1980_2005_female.xlsx // Data file for municipal unemployment rates (male workers aged 15-29, 30-49, and 50-64)
See Kondo (2016) for further information.

#2. Replication Guide
Implement two do-files "DO_Estimation_moransi.do" and "DO_Estimation_moransi.do"

#3. Notes
Small numerical errors in municipal unemployment rates were corrected in this replication dataset. The numbers in the original article are slightly different from those replicated in these replication codes. However, the qualitative results do not change at all.
