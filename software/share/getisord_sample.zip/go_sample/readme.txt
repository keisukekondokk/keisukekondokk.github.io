########################################
## (C) Keisuke Kondo
## Upload Date: October 01, 2016
########################################

This package includes the sample file for the Stata command "getisord", which 
is developed by Kondo (2016).

Kondo, K. (2016) "Hot and cold spot analysis using Stata," Stata Journal 16(3),
 pp. 613-631.


Contents
1. Guide
2. Original Shape File
3. Contact

========================================
1. Guide
========================================
Implement "DO_ncovr.do" on Stata. 

========================================
2. Original Shape File
========================================
The original NCOVR dataset is taken from GeoDa Center for Geospatial 
Analysis and Computation (URL: https://geodacenter.asu.edu/).

========================================
3. Contact
========================================
Name: Keisuke Kondo

Address: 
Research Institute of Economy, Trade and Industry (RIETI)
METI ANNEX 11th Floor
1-3-1 Kasumigaseki
Chiyoda-ku, Tokyo 100-8901
Japan

E-mail: kondo-keisuke /* at */ rieti.go.jp
(Please replace /* at */ by @.)
