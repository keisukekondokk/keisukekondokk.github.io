/***********************************************************
** (C) KEISUKE KONDO
** 
** Release Date: November 15, 2016
** Update Date: December 06, 2017
** Version: 1.10
** 
** [Reference]
** Combes, P.P., Duranton, G., Gobillon, L., Puga, D., and Roux, S., (2012) 
** "The Productivity Advantages of Large Cities: Distinguishing Agglomeration
** From Firm Selection," Econometrica 80(6), pp. 2543-2594
** 
** [Contact]
** Email: kondo-keisuke@rieti.go.jp
** URL: https://sites.google.com/site/keisukekondokk/
***********************************************************/


[Table of Contents]
1. Contents
2. Install Instruction for Stata Modules

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
1. Contents
- estquant.ado
  Program codes for estquant command
- estquant.sthlp
  Help file for estquant command


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
2. Install Instruction for Stata Modules
   (a). Find system directory for personal Stata ado-files (Type sysdir command)
        (e.g., default setting on Windows: c:\ado\personal\)
   (b). Save Stata ado-file (estquant.ado) and Stata help file (estquant.sthlp) 
        in the above directory.

