Install Instruction for Stata modules:
1. Find system directory for personal Stata ado-files (Type sysdir command).
   (e.g., default setting on Windows: c:\ado\personal\)
2. Unzip zip file and save Stata ado-file (e.g., moransi.ado) and Stata help file 
   (e.g., moransi.sthlp) in the above directory.
3. Try sample Stata do-file to confirm whether the Stata command works without 
   errors.

Update Instruction for Stata modules:
1. Find system directory for personal or plus Stata ado-files (Type sysdir command).
   (e.g., default setting on Windows: c:\ado\personal\ or c:\ado\plus\s\)
2. Unzip zip file and overwrite Stata ado-file (moransi.ado) and Stata help file 
   (moransi.sthlp) in the above directory.
